package com.example.demo.dto;

import lombok.*;

@Data
@AllArgsConstructor
public class MemberBoardDto {
	private Integer bno;
	private Boolean isGood;
}
