package com.example.demo.dao;

import java.util.*;

import org.apache.ibatis.annotations.*;

import com.example.demo.dto.*;

@Mapper
public interface CategoryDao {
	public List<CategoryDto> findAll();

}
