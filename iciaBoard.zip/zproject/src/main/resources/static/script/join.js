// 아이디 패턴 체크 함수
function usernameCheck() {
	$("#username_msg").text("");
	const pattern = /^[0-9A-Z]{8,10}$/;
	const $username = $("#username").val().toUpperCase();
	$("#username").val($username);
	const result = pattern.test($username);
	if(result==false)
		$("#username_msg").text("아이디는 대문자와 숫자 8~10자입니다").attr("class", "fail")
	return result;
}

// 이메일 패턴 체크 함수
function emailCheck() {
	$("#email_msg").text("");
	const pattern = /^[0-9a-zA-Z]([-_.]?[0-9a-zA-Z])*@[0-9a-zA-Z]([-_.]?[0-9a-zA-Z])*.[a-zA-Z]{2,3}$/i;
	const $email = $("#email").val();
	const result = pattern.test($email);
	if(result==false)
		$("#email_msg").text("이메일을 정확하게 입력하세요").attr("class", "fail");
	return result;
}

// 이름 패턴 체크 함수
function irumCheck() {
	$("#irum_msg").text("");
	const pattern = /^[가-힣]{2,10}$/; 
	const $irum = $("#irum").val();
	const result = pattern.test($irum);
	if(result==false)
		$("#irum_msg").text("이름은 한글 2~10자입니다");
	return result;
}

// 비밀번호 패턴 체크 함수
function passwordCheck() {
	$("#password_msg").text("");
	// (?=.*[!@#$%^&*])는 독립된 조건
	// ?=는 앞에서 부터
	// .은 임의의 글자
	// *는 0개 이상
	const pattern = /^(?=.*[!@#$%^&*])^[A-Za-z0-9!@#$%^&*]{8,10}$/;
	const $password = $("#password").val();
	const result = pattern.test($password);
	if(result==false)
		$("#password_msg").text("비밀번호는 특수문자를 하나이상 포함하는 영숫자와 특수문자 8~10자입니다");
	return result;
}

// 비밀번호 확인은 필수입력이고 비밀번호와 일치해야 한다
function password2Check() {
	$("#password2_msg").text("");
	const $password2 = $("#password2").val();
	if($password2=="") {
		$("#password2_msg").text("필수입력입니다");
		return false;
	} 
	if($password2!==$("#password").val()) {
		$("#password2_msg").text("비밀번호가 일치하지 않습니다");
		return false;
	}
	return true;
}

// 생일 패턴 체크 함수
function birthdayCheck() {
	$("#birthday_msg").text("");
	const pattern = /^[0-9]{4}-[0-9]{2}-[0-9]{2}$/;
	const $birthday = $("#birthday").val();
	const result = pattern.test($birthday);
	if(result==false)
		$("#birthday_msg").text("정확한 날짜를 입력하세요");
	return result;
}

// 프로필 사진을 출력하는 함수
function loadProfile() {
	const file = $("#profile")[0].files[0];
	const maxSize = 1024*1024;			
	if(file.size>maxSize) {
		Swal.fire('프로필 크기 오류', '프로필 사진은 1MB를 넘을 수 없습니다','error');
		$("#profile").val("");
		$("#show_profile").removeAttr("src");
		return false;
	}
	const reader = new FileReader();
	reader.readAsDataURL(file);
	reader.onload = function() {
		$("#show_profile").attr("src", reader.result);
	}
	return true;
}

// formData를 출력하는 함수
function printFormData(formData) {
	for(const key of formData.keys())
		console.log(key);
	for(const value of formData.values()) 
		console.log(value);
}

// 실제 회원가입하는 함수 
function join() {
	// multipart/form-data를 JS에서 다룰 때는 FormData 내장 객체를 사용
	// 1. 폼을 읽어와서 FormData 생성 : new FormData(폼)
	// 2. 비어있는 FormData를 생성한 다음 값을 하나씩 채워넣는 방식
	//	  const formData = new FormData();
	//	  formData.append("username", "spring");
	const formData = new FormData($("#join_form")[0]);
	
	$.ajax({
		url: "/member/new",
		method: "post",
		data: formData,
		processData: false,			// multipart/form-data 형식일 때 필수 설정
		contentType: false			// multipart/form-data 형식일 때 필수 설정
	})
	.done(()=>{
		// 가입 성공 메시지 출력하고 사용자가 확인하면 로그인 창으로 이동 
		Swal.fire("가입신청완료","이메일을 확인하세요","success").then((choice)=>{ if(choice.isConfirmed) location.href="/login"; })
	}).fail((response)=>{
		// 가입 신청 메시지 출력
		Swal.fire("가입신청실패", response.responseJSON.result, "error");
	});
}

$(document).ready(function() {
	// 프로필 사진을 변경하면 출력하기
	$("#profile").on("change", loadProfile);
	
	// 아이디에 대한 패턴 체크 -> 성공하면 사용가능 여부를 ajax로 확인
	$("#username").on("blur", function() {
		if(usernameCheck()==false)
			return;
		const $username = $('#username').val();
		$.ajax("/member/check/username?username="+$username)
		.done(response=>console.log(response.result))
		.fail(response=>$("#username_msg").text(response.result).attr("class","fail"));
		
	});
	
	// 이메일에 대한 패턴 체크 -> 성공하면 사용가능 여부를 ajax로 확인
	$("#email").on("blur", function() {
		if(emailCheck()==false)
			return;
		const $email = $('#email').val();
		$.ajax("/member/check/email?email="+$email).done(()=>$("#email_msg").text("사용가능합니다").attr("class", "success")).fail(()=>$("#email_msg").text("사용중입니다").attr("class","fail"));
		
	});
	
	$("#email").on("blur", emailCheck);
	$("#password").on("blur", passwordCheck);
	$("#password2").on("blur", password2Check);
	$("#irum").on("blur", irumCheck);
	$("#birthday").on("blur", birthdayCheck);
	
	// 가입 버튼 누르면 6개에 대해 검증을 수행
	$("#join").on("click", function() {
		// 6개 검증을 수행
		const r1 = usernameCheck();
		const r2 = passwordCheck();
		const r3 = password2Check();
		const r4 = irumCheck();
		const r5 = emailCheck();
		const r6 = birthdayCheck();
		if((r1 && r2 && r3 && r4 && r5 && r6) == false)
			return;
					
		// ajax로 사용여부 확인 다시
		$.when("/member/check/username?username="+$('#username').val(),
			"/member/check/email?email="+$('#email').val())
		.done(()=>join())
		.fail(()=>Swal.fire("실패", "아이디나 이메일이 사용중입니다", "error"));	
	})
	
})











